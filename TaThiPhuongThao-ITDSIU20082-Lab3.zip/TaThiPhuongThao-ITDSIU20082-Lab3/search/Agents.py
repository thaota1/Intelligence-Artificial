from game import Agent
from game import Directions
import random
from util import manhattanDistance

class DumbAgent(Agent):
    "An agent that goes East until it can't."
    def getAction(self, state):
        "The agent receives a GameState (defined in pacman.py)."
        print("Location: ", state.getPacmanPosition())
        print("Actions available: ", state.getLegalPacmanActions())
    
        if Directions.EAST in state.getLegalPacmanActions():
            print("Going East.")
            return Directions.EAST
        else:
            print("Stopping.")
            return Directions.STOP

# python pacman.py --layout myLayout --pacman RandomAgent
class RandomAgent(Agent):
    def getAction(self, state):
        print("Location: ", state.getPacmanPosition())
        print("Actions available: ", state.getLegalPacmanActions())
        return random.choice(state.getLegalPacmanActions())

# python pacman.py --layout myLayout --pacman BetterRandomAgent
class BetterRandomAgent(Agent):
    def getAction(self, state):
        "The agent receives a GameState (defined in pacman.py)."
        print("Location: ", state.getPacmanPosition())
        AvailableAction = state.getLegalPacmanActions()
        AvailableAction.remove(AvailableAction[-1])
        print("Actions available: ", AvailableAction)
        return random.choice(AvailableAction)

# python pacman.py --layout myLayout --pacman ReflexAgent
class ReflexAgent(Agent):
    def getAction(self, gameState):
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalPacmanActions()
        legalMoves.remove(legalMoves[-1])
        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        # Useful information you can extract from a gameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPositions = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        foodNum = currentGameState.getFood().count()
        if len(newFood.asList()) == foodNum:  # if this action does not eat a food 
            distance = 3000
            for pt in newFood.asList():
                if manhattanDistance(pt , newPositions) < distance:
                    distance = manhattanDistance(pt, newPositions)
        else:
            distance = 0
        for ghost in newGhostStates:  # the impact of ghost surges as distance get close
            distance += 4 ** (2 - manhattanDistance(ghost.getPosition(), newPositions))
        return -distance