Open command prompt inside the lab directory
Exercise 1:
To run the test with the Depth-First Search, type in comman prompt:
Tiny maze: 		python pacman.py -l tinyMaze -p SearchAgent -a fn=dfs
Medium maze: 		python pacman.py -l mediumMaze -p SearchAgent -a fn=dfs
Big maze: 		python pacman.py -l bigMaze -p SearchAgent -z .5 -a fn=dfs

Exercise 2:
To run the test with the Breadth-First Search, type in comman prompt:
Tiny maze: 		python pacman.py -l tinyMaze -p SearchAgent -a fn=bfs
Medium maze: 		python pacman.py -l mediumMaze -p SearchAgent -a fn=bfs
Big maze: 		python pacman.py -l bigMaze -p SearchAgent -z .5 -a fn=bfs

Exercise 3:
To run the test with the Uniform Cost Search, type in comman prompt:
Tiny maze: 		python pacman.py -l tinyMaze -p SearchAgent -a fn=ucs
Medium maze: 		python pacman.py -l mediumMaze -p SearchAgent -a fn=ucs
Big maze: 		python pacman.py -l bigMaze -p SearchAgent -z .5 -a fn=ucs

Medium Maze: 		python pacman.py -l mediumMaze -p SearchAgent -a fn=ucs
Medium Dotted Maze: 	python pacman.py -l mediumDottedMaze -p StayEastSearchAgent
Medium Scary Maze: 	python pacman.py -l mediumScaryMaze -p StayWestSearchAgent