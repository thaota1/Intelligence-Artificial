To run the game, open the command promp in the directory contain the file
For agent in step 7:
python pacman.py --layout myLayout --pacman RandomAgent

For agent in step 9:
python pacman.py --layout myLayout --pacman BetterRandomAgent

For agent in step 10: 
python pacman.py --layout myLayout --pacman ReflexAgent
